function ExecuteScript(strId)
{
  switch (strId)
  {
      case "5bcBO22ZCaA":
        Script1();
        break;
  }
}

function Script1()
{
  window.close();
}

